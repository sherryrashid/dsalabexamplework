public class ReverseArrayExample {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        
        System.out.println("Original Array:");
        printArray(numbers);
        
        reverseArray(numbers);
        
        System.out.println("Reversed Array:");
        printArray(numbers);
    }
    
    public static void reverseArray(int[] array) {
        int leftIndex = 0;
        int rightIndex = array.length - 1;
        
        while (leftIndex < rightIndex) {
            int temp = array[leftIndex];
            array[leftIndex] = array[rightIndex];
            array[rightIndex] = temp;
            
            leftIndex++;
            rightIndex--;
        }
    }
    
    public static void printArray(int[] array) {
        for (int number : array) {
            System.out.print(number + " ");
        }
        System.out.println();
    }
}
