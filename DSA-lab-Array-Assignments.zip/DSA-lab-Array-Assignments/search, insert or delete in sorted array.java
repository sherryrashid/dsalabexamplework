import java.util.Arrays;

public class SortedArrayOperations {

    public static int binarySearch(int[] array, int key) {
        int leftIndex = 0; 
        int rightIndex = array.length - 1; 

        while (leftIndex <= rightIndex) {
            int midIndex = leftIndex + (rightIndex - leftIndex) / 2; 
            
            if (array[midIndex] == key) {
                return midIndex; 
            }
            if (array[midIndex] < key) {
                leftIndex = midIndex + 1;
            } else {
                rightIndex = midIndex - 1;
            }
        }
        return -1; 
    }

    public static int[] insert(int[] array, int key) {
        int originalLength = array.length; 
        int[] updatedArray = new int[originalLength + 1]; 
        int insertIndex;

        for (insertIndex = 0; insertIndex < originalLength; insertIndex++) {
            if (array[insertIndex] > key) {
                break; 
            }
            updatedArray[insertIndex] = array[insertIndex]; 
        }

        updatedArray[insertIndex] = key; 

        for (int j = insertIndex; j < originalLength; j++) {
            updatedArray[j + 1] = array[j];
        }

        return updatedArray; 
    }

    public static int[] delete(int[] array, int key) {
        // First, check if the key exists in the array
        int keyIndex = binarySearch(array, key);
        if (keyIndex == -1) {
            System.out.println("Element " + key + " not found in the array."); 
            return array; 
        }

        int newLength = array.length; 
        int[] updatedArray = new int[newLength - 1]; 

        for (int i = 0, j = 0; i < newLength; i++) {
            if (i != keyIndex) {
                updatedArray[j++] = array[i]; 
            }
        }

        return updatedArray; 
    }

    public static void main(String[] args) {
        int[] sortedArray = {1, 3, 5, 7, 9};
        System.out.println("Original array: " + Arrays.toString(sortedArray));

        int searchResult = binarySearch(sortedArray, 5);
        System.out.println("Search Result Index for 5: " + searchResult);

        sortedArray = insert(sortedArray, 6);
        System.out.println("Array after inserting 6: " + Arrays.toString(sortedArray));

        sortedArray = delete(sortedArray, 3);
        System.out.println("Array after deleting 3: " + Arrays.toString(sortedArray));
    }
}
