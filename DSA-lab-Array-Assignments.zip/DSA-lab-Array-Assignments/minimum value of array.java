public class MinValueArray {
    public static void main(String[] args) {
        int[] numbers = {5, 2, 8, 1, 3}; 
        int minValue = findMinimum(numbers);
        System.out.println("The minimum value in the array is: " + minValue);
    }

    public static int findMinimum(int[] array) {
        int minValue = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] < minValue) {
                minValue = array[i];
            }
        }
        return minValue;
    }
}
