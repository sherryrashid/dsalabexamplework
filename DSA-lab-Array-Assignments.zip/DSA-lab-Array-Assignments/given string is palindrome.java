public class PalindromeChecker {

    public static boolean checkIfPalindrome(String input) {
        String cleanedInput = input.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        int start = 0;
        int end = cleanedInput.length() - 1;

        while (start < end) {
            if (cleanedInput.charAt(start) != cleanedInput.charAt(end)) {
                return false;
            }
            start++;
            end--;
        }
        return true;
    }

    public static void main(String[] args) {
        String testString = "Never odd or even.";
        boolean isPalindrome = checkIfPalindrome(testString);

        if (isPalindrome) {
            System.out.println("\"" + testString + "\" is a palindrome!");
        } else {
            System.out.println("\"" + testString + "\" is not a palindrome.");
        }
    }
}

