import java.util.Arrays;

public class ResizeArrayExample {
    public static void main(String[] args) {
        int[] originalArray = {1, 2, 3, 4, 5};
        int newSize = 8; 
        
        int[] resizedArray = resizeArray(originalArray, newSize);
        
        System.out.println("Resized Array: " + Arrays.toString(resizedArray));
    }

    public static int[] resizeArray(int[] original, int newSize) {
        int[] newArray = new int[newSize];
        
        for (int i = 0; i < Math.min(original.length, newSize); i++) {
            newArray[i] = original[i];
        }
        
        return newArray;
    }
}
