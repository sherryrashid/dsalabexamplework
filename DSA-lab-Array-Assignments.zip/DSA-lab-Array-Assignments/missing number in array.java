public class MissingNumberFinder {

    public static int findMissingNumber(int[] numbers) {
        int expectedSize = numbers.length + 1;
        int expectedSum = expectedSize * (expectedSize + 1) / 2;
        int actualSum = 0;

        for (int number : numbers) {
            actualSum += number;
        }

        return expectedSum - actualSum;
    }

    public static void main(String[] args) {
        int[] numbers = {1, 2, 4, 5};
        int missingNumber = findMissingNumber(numbers);
        System.out.println("The missing number is: " + missingNumber);
    }
}
