public class SecondMaxFinder {

    public static void main(String[] args) {
        int[] numbers = {3, 5, 7, 2, 8, 1};   

        int secondMaxValue = findSecondMax(numbers);
        
        if (secondMaxValue != Integer.MIN_VALUE) {
            System.out.println("The second maximum value is: " + secondMaxValue);
        } else {
            System.out.println("Hmm, it looks like there's no second maximum value in the array.");
        }
    }

    public static int findSecondMax(int[] array) {
        if (array.length < 2) {
            return Integer.MIN_VALUE; 
        }
        
        int maxValue = Integer.MIN_VALUE;      
        int secondMaxValue = Integer.MIN_VALUE; 

        for (int number : array) {
            if (number > maxValue) {
                secondMaxValue = maxValue; 
                maxValue = number;          
            } else if (number > secondMaxValue && number < maxValue) {
                secondMaxValue = number; 
            }
        }

        return secondMaxValue; 
    }
}