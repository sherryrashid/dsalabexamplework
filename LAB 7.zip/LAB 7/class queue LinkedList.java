class LinkedList {
    private Node front;
    private Node rear;

    public static class Node {
        public int data;
        public Node next;

        // Constructor to create a new node
        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // Method to insert a node at the end (enqueue)
    public void enqueue(int data) {
        Node newNode = new Node(data);
        if (rear == null) {
            // If the queue is empty, both front and rear will point to the new node
            front = rear = newNode;
        } else {
            // Add the new node at the end and update rear
            rear.next = newNode;
            rear = newNode;
        }
    }

    // Method to remove the front node (dequeue)
    public void dequeue() {
        if (front == null) {
            System.out.println("Queue is empty, can't dequeue.");
            return;
        }
        // Move the front pointer to the next node
        front = front.next;

        // If the front becomes null, it means the queue is empty, so rear should also be null
        if (front == null) {
            rear = null;
        }
    }

    // Method to view the front element of the queue without removing it
    public int peek() {
        if (front == null) {
            System.out.println("Queue is empty.");
            return -1;  // Indicating the queue is empty
        }
        return front.data;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return front == null;
    }

    // Method to display the elements in the queue
    public void displayQueue() {
        if (front == null) {
            System.out.println("Queue is empty.");
            return;
        }
        Node current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

class Queue {
    LinkedList list = new LinkedList();

    // Method to enqueue (add an element to the queue)
    public void enqueue(int element) {
        list.enqueue(element);
    }

    // Method to dequeue (remove an element from the queue)
    public void dequeue() {
        list.dequeue();
    }

    // Method to view the front element of the queue
    public int peek() {
        return list.peek();
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return list.isEmpty();
    }

    // Method to display the queue
    public void displayQueue() {
        System.out.println("Queue elements:");
        list.displayQueue();
    }
}

class QueueClient {
    public static void main(String[] args) {
        Queue queue = new Queue();  
        
        // Enqueue elements to the queue
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);

        // Display the queue
        System.out.println("Queue after enqueue operations:");
        queue.displayQueue();

        // Peek at the front element
        System.out.println("Front element: " + queue.peek());

        // Dequeue an element
        queue.dequeue();
        System.out.println("Queue after dequeue operation:");
        queue.displayQueue();

        // Peek again to show the new front element
        System.out.println("Front element after dequeue: " + queue.peek());

        // Dequeue all remaining elements
        queue.dequeue();
        queue.dequeue();
        queue.dequeue();
        queue.dequeue(); 
    }
}