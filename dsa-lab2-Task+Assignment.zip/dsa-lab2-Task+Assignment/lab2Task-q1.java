import java.util.ArrayList;

public class ArrayModifier {

    public static void insertItem(ArrayList<Integer> list, int index, int item) {
        if (index < 0 || index > list.size() || item <= 0) {
            return;
        }
        
        if (index < list.size() && list.get(index) >= item) {
            return;
        }
        
        list.add(index, item);
    }

    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);

        int index = 2;
        int item = 25;

        insertItem(list, index, item);
    }
}
