import java.io.*;
import java.util.Scanner;

public class ConsoleNotepad{
    private static class Node {
        char data;
        Node prev, next, above, below;

        Node(char data) {
            this.data = data;
        }
    }

    private Node head, cursor;
    private Node cursorLineHead;

    public ConsoleNotepad() {
        head = new Node('\0');
        cursor = head;
        cursorLineHead = head;
    }


    private void insertChar(char ch) {
        Node newNode = new Node(ch);
        newNode.prev = cursor;
        newNode.next = cursor.next;

        if (cursor.next != null) {
            cursor.next.prev = newNode;
        }
        cursor.next = newNode;
        cursor = newNode;
    }


    private void deleteChar() {
        if (cursor.prev == null || cursor == head) return; // Nothing to delete
        Node toDelete = cursor.prev;

        if (toDelete.prev != null) {
            toDelete.prev.next = cursor;
        }
        cursor.prev = toDelete.prev;
    }


    private void moveCursorLeft() {
        if (cursor.prev != null) {
            cursor = cursor.prev;
        }
    }


    private void moveCursorRight() {
        if (cursor.next != null) {
            cursor = cursor.next;
        }
    }


    private void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("save.txt"))) {
            head = new Node('\0');
            cursor = head;
            cursorLineHead = head;
            String line;

            while ((line = reader.readLine()) != null) {
                for (char ch : line.toCharArray()) {
                    insertChar(ch);
                }
                insertChar('\n');
            }
        } catch (IOException e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }


    private void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("save.txt"))) {
            Node line = head.next;

            while (line != null) {
                if (line.data == '\n') {
                    writer.newLine();
                } else {
                    writer.write(line.data);
                }
                line = line.next;
            }
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }


    private void display() {
        Node current = head.next;
        System.out.println("\033[H\033[2J"); // clears console
        System.out.flush();
        while (current != null) {
            if (current == cursor) {
                System.out.print("|"); // indicates cursor position
            }
            if (current.data != '\0') {
                System.out.print(current.data);
            }
            current = current.next;
        }
        System.out.println();
    }


    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Console Notepad");
        System.out.println("Controls of Notepad:");
        System.out.println("- Use 'Ctrl + S' to save, 'Ctrl + L' to load, 'Esc' to quit.");
        System.out.println("- Use arrow keys to move cursor.");
        System.out.println("- Use backspace to delete.");

        loadFromFile();

        while (true) {
            display();

            String command = scanner.nextLine();
            //all in caps
            switch (command) {
                case "S":
                    saveToFile();
                    break;
                case "L":
                    loadFromFile();
                    break;
                case "E":
                    System.exit(0);
                    break;
                case "B":
                    deleteChar();
                    break;
                case "T": //left cursor
                    moveCursorLeft();
                    break;
                case "R":
                    moveCursorRight();
                    break;
                default:
                    if (command.length() == 1) {
                        insertChar(command.charAt(0));
                    }
            }
        }
    }

    public static void main(String[] args) {
        ConsoleNotepad notepad = new ConsoleNotepad();
        notepad.start();
    }
}

